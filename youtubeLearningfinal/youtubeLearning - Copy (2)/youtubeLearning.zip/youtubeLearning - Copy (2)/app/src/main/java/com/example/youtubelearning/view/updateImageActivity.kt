package com.example.youtubelearning.view

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.youtubelearning.R
import com.example.youtubelearning.databinding.ActivityUpdateImageBinding

class updateImageActivity : AppCompatActivity() {

    lateinit var updateImageBinding: ActivityUpdateImageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        updateImageBinding = ActivityUpdateImageBinding.inflate(layoutInflater)
        setContentView(updateImageBinding.root)


        updateImageBinding.imageViewUpdateImage.setOnClickListener{

        }
        updateImageBinding.buttonUpdate.setOnClickListener{

        }
        updateImageBinding.toolBarUpdateImage.setNavigationOnClickListener{
            finish()
        }
    }


}