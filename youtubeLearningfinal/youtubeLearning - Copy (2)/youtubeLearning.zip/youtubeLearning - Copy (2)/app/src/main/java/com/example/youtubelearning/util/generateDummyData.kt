import com.example.youtubelearning.model.MyImages
import java.util.Date

fun generateDummyData(): List<MyImages> {
    return listOf(
        MyImages(
            imageTittle = "Sunset at the Beach",
            imageDescription = "A beautiful sunset over the ocean",
            image = "https://example.com/sunset_beach.jpg",
            loction = "Hawaii",
            date = Date(System.currentTimeMillis() - (1000 * 60 * 60 * 24 * 5)) // 5 days ago
        ),
        MyImages(
            imageTittle = "Mountain Hiking",
            imageDescription = "A challenging hike up the mountains",
            image = "https://example.com/mountain_hiking.jpg",
            loction = "Swiss Alps",
            date = Date(System.currentTimeMillis() - (1000 * 60 * 60 * 24 * 10)) // 10 days ago
        ),
        MyImages(
            imageTittle = "City Night Lights",
            imageDescription = "The city skyline illuminated at night",
            image = "https://example.com/city_night_lights.jpg",
            loction = "New York",
            date = Date(System.currentTimeMillis() - (1000 * 60 * 60 * 24 * 2)) // 2 days ago
        ),
        MyImages(
            imageTittle = "Food Delights",
            imageDescription = "A close-up of a delicious burger",
            image = "https://example.com/food_delights.jpg",
            loction = "Los Angeles",
            date = Date(System.currentTimeMillis() - (1000 * 60 * 60 * 24 * 30)) // 30 days ago
        ),
        MyImages(
            imageTittle = "Nature's Beauty",
            imageDescription = "A lush green forest with a stream running through it",
            image = "https://example.com/nature_beauty.jpg",
            loction = "Costa Rica",
            date = Date(System.currentTimeMillis() - (1000 * 60 * 60 * 24 * 15)) // 15 days ago
        )
    )
}
