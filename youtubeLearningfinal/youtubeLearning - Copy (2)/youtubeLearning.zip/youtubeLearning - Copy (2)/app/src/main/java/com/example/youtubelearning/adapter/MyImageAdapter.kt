package com.example.youtubelearning.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.youtubelearning.databinding.ImageItemBinding
import com.example.youtubelearning.model.MyImages
import com.example.youtubelearning.util.ConvertImage

class MyImageAdapter: RecyclerView.Adapter<MyImageAdapter.MyImageViewHolder>() {

    var imageList : List<MyImages> = listOf()

    fun setImage(images: List<MyImages>){
        this.imageList = images
        notifyDataSetChanged()
    }


    class MyImageViewHolder(val itemBinding: ImageItemBinding) : RecyclerView.ViewHolder(itemBinding.root){

        fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyImageViewHolder {
            val view = ImageItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
            return MyImageViewHolder(view)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyImageViewHolder {
        val view = ImageItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return MyImageViewHolder(view)
    }


    override fun getItemCount(): Int {
        return imageList.size
    }

    override fun onBindViewHolder(holder: MyImageViewHolder, position: Int) {
        var myImage = imageList[position]
        with(holder){
            itemBinding.textViewTitle.text = myImage.imageTittle
            itemBinding.textViewDescription.text = myImage.imageDescription
//            val imagesAsBitmap = ConvertImage.convertToBitmap(myImage.image)
//            itemBinding.imageView.setImageBitmap(imagesAsBitmap)

        }
    }
    fun updateData(newImages: List<MyImages>) {
        (newImages as MutableList).clear()
        newImages.addAll(newImages)
        notifyDataSetChanged()
    }
}