package com.example.youtubelearning.util

import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.IOException
import android.graphics.BitmapFactory

class ConvertImage {

    companion object {
        @JvmStatic
        fun convertToBitmap(imageAsString: String): Bitmap? {
            return try {
                // Decode the Base64 string into a byte array
                val decodedByteArray = Base64.decode(imageAsString, Base64.DEFAULT)

                // Convert the byte array to a Bitmap
                BitmapFactory.decodeByteArray(decodedByteArray, 0, decodedByteArray.size)
            } catch (e: IllegalArgumentException) {
                e.printStackTrace()
                null
            } catch (e: IOException) {
                e.printStackTrace()
                null
            }
        }
    }
}
