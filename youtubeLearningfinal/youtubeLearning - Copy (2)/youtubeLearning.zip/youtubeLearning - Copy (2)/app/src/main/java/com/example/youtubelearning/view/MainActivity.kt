package com.example.youtubelearning.view

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.youtubelearning.R
import com.example.youtubelearning.adapter.MyImageAdapter
import com.example.youtubelearning.databinding.ActivityAddImageAtivityBinding
import com.example.youtubelearning.databinding.ActivityMainBinding
import com.example.youtubelearning.room.MyImageDao
import com.example.youtubelearning.viewModel.MyImageViewModel
import generateDummyData
import com.example.youtubelearning.room.MyImagesDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.activity.viewModels

class MainActivity : AppCompatActivity() {
    //this is test purpose
    private lateinit var db: MyImagesDatabase



    lateinit var mainBinding : ActivityMainBinding
    lateinit var myImageAdapter: MyImageAdapter
    private lateinit var myImageDao: MyImageDao
    private val myImagesViewModel: MyImageViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

//        adding sample to data base
        addSampleToDataBase()


        mainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mainBinding.root)



        mainBinding.recyclerview.layoutManager = LinearLayoutManager(this)
        myImageAdapter = MyImageAdapter()
        mainBinding.recyclerview.adapter = myImageAdapter

        myImagesViewModel.getAllImages().observe(this,{ images ->
            myImageAdapter.setImage(images)
        })

        mainBinding.add.setOnClickListener{
            val intent = Intent(this,addImageAtivity::class.java)
            startActivity(intent)
        }


    }



    private fun addSampleToDataBase() {
        val dummyData = generateDummyData()
        var db: MyImagesDatabase
        db = Room.databaseBuilder(applicationContext, MyImagesDatabase::class.java, "my_database")
            .fallbackToDestructiveMigration() // This will clear old data if you change your schema
            .build()

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val myImageDao: MyImageDao = db.myImageDao()
                dummyData.forEach{
                        entity ->
                    myImageDao.insert(entity)
                }


            } catch (e: Exception) {

            }
        }
    }
}